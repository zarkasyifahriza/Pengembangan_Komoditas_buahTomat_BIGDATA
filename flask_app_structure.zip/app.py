from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
import matplotlib.patches as mpatches
import os
import cv2
import joblib
from skimage.feature import local_binary_pattern
import io
import base64

# Initialize Flask app
app = Flask(__name__, template_folder="templates")

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/time_series', methods=['GET', 'POST'])
def time_series():
    return render_template('time_series.html')

@app.route('/kmeans', methods=['GET', 'POST'])
def kmeans():
    return render_template('kmeans.html')

@app.route('/classify', methods=['GET', 'POST'])
def classify():
    return render_template('classify.html')

if __name__ == '__main__':
    app.run(debug=True)
